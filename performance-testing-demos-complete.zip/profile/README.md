# 👋 Hi, I'm Aleksandr

<h3 align="center">Performance & Load Testing Engineer | JMeter • k6 • Locust • Grafana • CI/CD</h3>

---

### ⚡ About Me
- 🔬 Specialized in **Performance, Load, and Stress Testing**  
- 🚀 Experience with **JMeter, k6, Locust, Grafana, Jenkins, CI/CD**  
- 🌍 Available for remote contracts worldwide  
- 📊 Building scalable, automated testing pipelines

---

### 🧰 Tech Stack
<p align="center">
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/apache/apache-original.svg" height="40" title="Apache JMeter"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg" height="40" title="k6"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg" height="40" title="Locust"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/grafana/grafana-original.svg" height="40" title="Grafana"/>
  <img src="https://cdn.jsdelivr.net/gh/devicons/devicon/icons/jenkins/jenkins-original.svg" height="40" title="Jenkins"/>
</p>

---

### 🌐 Connect With Me
<p align="center">
  <a href="https://www.upwork.com/"><img src="https://img.shields.io/badge/Upwork-6FDA44?style=for-the-badge&logo=upwork&logoColor=white"/></a>
  <a href="https://contra.com/"><img src="https://img.shields.io/badge/Contra-2E2E2E?style=for-the-badge&logo=contra&logoColor=white"/></a>
  <a href="mailto:aleksandr.qa.performance@gmail.com"><img src="https://img.shields.io/badge/Email-0078D4?style=for-the-badge&logo=gmail&logoColor=white"/></a>
</p>
